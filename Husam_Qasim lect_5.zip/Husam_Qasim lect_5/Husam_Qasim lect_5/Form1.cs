﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lecture_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;bool f = false;
            if (checkBox1.Checked)
            {
                sum += Convert.ToInt32(checkBox1.Text); f=true;
            }
            if (checkBox2.Checked)
            {
                sum += Convert.ToInt32(checkBox2.Text); f = true;
            }
            if (checkBox3.Checked)
            {
                sum += Convert.ToInt32(checkBox3.Text); f = true;
            }
            if (checkBox4.Checked)
            {
                sum += Convert.ToInt32(checkBox4.Text); f = true;
            }
            if (checkBox5.Checked)
            {
                sum += Convert.ToInt32(checkBox5.Text); f = true;
            }
            if (f)
            {
                txtresult.Text = sum.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButtonyellow.Checked)
                label2.BackColor = Color.Yellow;
            else if (radioButtongreen.Checked)
                label2.BackColor = Color.Green;
            else if (radioButtonred.Checked)
                label2.BackColor = Color.Red;
            else if (radioButtonblack.Checked)
                label2.BackColor = Color.Black;
            if (radioButton1.Checked)
                label2.ForeColor = Color.Yellow;
            else if (radioButton2.Checked)
                label2.ForeColor = Color.Green;
            else if (radioButton3.Checked)
                label2.ForeColor = Color.Red;
            else if (radioButton4.Checked)
                label2.ForeColor = Color.Black;
        }

        private void btnenabled_Click(object sender, EventArgs e)
        {
            panelbackcolor.Enabled = true;
        }

        private void btnunabled_Click(object sender, EventArgs e)
        {
            panelbackcolor.Enabled = false;
        }

        private void btnvisible_Click(object sender, EventArgs e)
        {
            panelbackcolor.Visible = true;
        }

        private void btnunvisible_Click(object sender, EventArgs e)
        {
            panelbackcolor.Visible = false;
        }


        //private void radioButton1_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (radioButton1.Checked)
        //        label1.BackColor = Color.Yellow;
        //    else if (radioButton2.Checked)
        //        label1.BackColor = Color.Black;
        //}
    }
}
