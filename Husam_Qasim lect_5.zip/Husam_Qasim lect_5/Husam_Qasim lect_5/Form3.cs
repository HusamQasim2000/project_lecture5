﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lecture_5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            //for (int i = 0; i < 16; i++)
            //{
            //    button1.Left += 10;
            //}
            for (int i = 0; i < this.Width - button1.Width; i++)
            {
                button1.Left -= 1;
            }

            //// الحلقة الثانية: تحريك الزر إلى منتصف الشاشة
            //for (int i = 0; i < this.Width / 2; i++)
            //{
            //    button1.Left += 1;
            //}

            //// الحلقة الثالثة: تأخير التنفيذ (غير ضروري وممكن إزالته)
            //for (int j = 0; j < 1000000000; j++) ;

            // الحلقة الرابعة: تحريك الزر إلى اليمين
            for (int i = 0; i < this.Width; i++)
            {
                button1.Left += 10;


                // استخدام Thread.Sleep لإيقاف مؤقت قصير
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();

                // إذا تجاوز الزر حافة الشاشة، قم بوقفه
                if (button1.Left > this.Width - button1.Width)
                {
                    break;
                }
            }



            // إنشاء مؤشر ترابط جديد لتنفيذ الدالة go()
            threadgo = new Thread(go);
            threadgo.Start();

        }
        Thread threadgo;
            // الدالة go() التي تعمل في مؤشر ترابط منفصل
             void go()
    {
                for (int i = 0; i < this.Width; i++)
                {
                    // استخدام Invoke للوصول إلى عناصر التحكم من مؤشر ترابط آخر
                    Invoke((Action)(() =>
                    {
                        button1.Left += 10;
                    }));

                    // إذا تجاوز الزر حافة الشاشة، قم بوقفه
                    if (button1.Left > this.Width - button1.Width - 50)
                    {
                        break;
                    }

                    // تأخير التنفيذ وإعطاء الفرصة للتطبيقات الأخرى
                    System.Threading.Thread.Sleep(100);
                    Application.DoEvents();
                }
            }

        private void button4_Click(object sender, EventArgs e)
        {
   
            
        }

       

        private void button3_Click(object sender, EventArgs e)
        {
            //بالزر button1 لأعلى 400 وحدة بكسل
            //for (int i = 0; i < 400; i++)
            //{
            //    button1.Top += 1;
            //}

            //// هذه الحلقة تتحرك بالزر button4 إلى أسفل حتى يصل إلى قيمة معينة
            //for (int i = 0; i <= this.Height - button4.Height - 70; i++)
            //{
            //    button4.Top += 1;
            //    System.Threading.Thread.Sleep(100); // تأخير 100 مللي ثانية
            //    Application.DoEvents(); // تحديث واجهة المستخدم
            //}

            //هذه الحلقة تستمر في تحريك الزر button4 حتى يصل إلى الحد الأقصى
            for (int i = button4.Top; i < this.Height - button4.Height - 70; i++)
            {
                if (button4.Top > this.Height - button4.Height - 70)
                {
                    break; // إذا تجاوز الزر الحد، قم بإنهاء الحلقة
                }
                button4.Top += 10;
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();
            }
        }
        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadgo != null)
            {
                threadgo.Abort(); // إذا كان هناك مؤشر ترابط نشط، قم بإنهائه
            }

        }
    }
    
}
