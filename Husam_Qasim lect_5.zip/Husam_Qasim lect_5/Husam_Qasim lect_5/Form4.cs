﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lecture_5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;

            // تحديد موقع الألواح (يمكن تعديل هذه القيم حسب الحاجة)
            panel1.Location = new Point(1, 60);
            panel2.Location = panel1.Location;
            panel3.Location = panel1.Location;
            panel4.Location = panel1.Location;

            // ضبط حجم النموذج (يمكن تعديل هذه القيم حسب الحاجة)
            this.Height = button11.Height + 50;
            this.Width = button12.Left + button12.Width + 10;

            // ربط جميع الأزرار بحدث النقر على الزر الأول (button1_Click)
            button3.Click += button2_Click;
            button5.Click += button2_Click;
            button7.Click += button2_Click;
            // ربط جميع مربعات النص بحدث الضغط على مفتاح في مربع النص الثالثة (textBox3_KeyPress)
            //textBox2.KeyPress += textBox3.KeyPress;
            textBox3.KeyPress += textBox3_KeyPress;
            textBox4.KeyPress += textBox3_KeyPress;
            textBox5.KeyPress += textBox3_KeyPress;
            textBox6.KeyPress += textBox3_KeyPress;
            textBox7.KeyPress += textBox3_KeyPress;
            textBox8.KeyPress += textBox3_KeyPress;
            textBox9.KeyPress += textBox3_KeyPress;
            textBox10.KeyPress += textBox3_KeyPress;
            textBox11.KeyPress += textBox3_KeyPress;
            textBox12.KeyPress += textBox3_KeyPress;
            // إخفاء جميع الألواح في البداية
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            button2.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // إظهار اللوحة الأولى وإخفاء الباقي
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            button2.Visible = false;
            // تغيير ارتفاع النموذج (يمكن تعديل هذه القيمة حسب الحاجة)
            //this.Height = panel2.Height * 2;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // إظهار اللوحة الأولى وإخفاء الباقي
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;
            // تغيير ارتفاع النموذج (يمكن تعديل هذه القيمة حسب الحاجة)
            this.Height = panel2.Height * 2;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // إظهار اللوحة الأولى وإخفاء الباقي
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
            // تغيير ارتفاع النموذج (يمكن تعديل هذه القيمة حسب الحاجة)
            this.Height = panel2.Height * 2;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            // إظهار اللوحة الثانية وإخفاء الباقي
            panel1.Visible = false;
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            // تغيير ارتفاع النموذج (يمكن تعديل هذه القيمة حسب الحاجة)
            this.Height = panel2.Height * 2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2.Text.Trim()) && !string.IsNullOrEmpty(textBox3.Text.Trim()))
            {
                int result = Convert.ToInt32(textBox3.Text) - Convert.ToInt32(textBox2.Text);
                textBox1.Text = Convert.ToString(result);
            }
            else
            {
                MessageBox.Show("أدخل قيماً صحيحة");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4_Load(null, null);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ((textBox4.Text.Trim() != "") && (textBox5.Text.Trim() != ""))
            {
                if (textBox5.Text != "0")
                {
                    textBox6.Text = Convert.ToString(Convert.ToInt32(textBox4.Text) / Convert.ToInt32(textBox5.Text));
                }
                else
                {
                    MessageBox.Show("error divided by zero");
                }

            }
            else
            {
                MessageBox.Show("أدخل رقما");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if ((textBox7.Text.Trim() != "") && (textBox8.Text.Trim() != ""))
            {
                textBox9.Text = Convert.ToString(Convert.ToInt32(textBox7.Text) + Convert.ToInt32(textBox8.Text));
            }
            else
            {
                MessageBox.Show("أدخل رقما");
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((textBox10.Text.Trim() != "") && (textBox11.Text.Trim() != ""))
            {
                textBox12.Text = Convert.ToString(Convert.ToInt32(textBox10.Text) * Convert.ToInt32(textBox11.Text));
            }
            else
            {
                MessageBox.Show("أدخل رقما");
            }

        }
    }
}
