﻿namespace lecture_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelbackcolor = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.radioButtonyellow = new System.Windows.Forms.RadioButton();
            this.radioButtongreen = new System.Windows.Forms.RadioButton();
            this.radioButtonred = new System.Windows.Forms.RadioButton();
            this.radioButtonblack = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.btnenabled = new System.Windows.Forms.Button();
            this.btnunabled = new System.Windows.Forms.Button();
            this.btnvisible = new System.Windows.Forms.Button();
            this.btnunvisible = new System.Windows.Forms.Button();
            this.panelbackcolor.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelbackcolor
            // 
            this.panelbackcolor.Controls.Add(this.label2);
            this.panelbackcolor.Controls.Add(this.radioButtonyellow);
            this.panelbackcolor.Controls.Add(this.label1);
            this.panelbackcolor.Controls.Add(this.radioButtongreen);
            this.panelbackcolor.Controls.Add(this.radioButtonred);
            this.panelbackcolor.Controls.Add(this.radioButtonblack);
            this.panelbackcolor.Location = new System.Drawing.Point(0, 0);
            this.panelbackcolor.Name = "panelbackcolor";
            this.panelbackcolor.Size = new System.Drawing.Size(104, 192);
            this.panelbackcolor.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "لون الخلفية";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(26, 53);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton2.Size = new System.Drawing.Size(56, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "الاخضر";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(26, 30);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton1.Size = new System.Drawing.Size(55, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "الاصفر";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton4);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Location = new System.Drawing.Point(131, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(111, 192);
            this.panel2.TabIndex = 0;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(28, 76);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton3.Size = new System.Drawing.Size(54, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "الاحمر";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 133);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "تطبيق";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(26, 99);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton4.Size = new System.Drawing.Size(56, 17);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "الاسود";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.txtresult);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(273, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(150, 192);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "z";
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(23, 162);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(100, 20);
            this.txtresult.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(37, 133);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "احسب";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(56, 53);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox2.Size = new System.Drawing.Size(44, 17);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "300";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(56, 34);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox1.Size = new System.Drawing.Size(44, 17);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "200";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // radioButtonyellow
            // 
            this.radioButtonyellow.AutoSize = true;
            this.radioButtonyellow.Location = new System.Drawing.Point(25, 30);
            this.radioButtonyellow.Name = "radioButtonyellow";
            this.radioButtonyellow.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButtonyellow.Size = new System.Drawing.Size(55, 17);
            this.radioButtonyellow.TabIndex = 8;
            this.radioButtonyellow.TabStop = true;
            this.radioButtonyellow.Text = "الاصفر";
            this.radioButtonyellow.UseVisualStyleBackColor = true;
            // 
            // radioButtongreen
            // 
            this.radioButtongreen.AutoSize = true;
            this.radioButtongreen.Location = new System.Drawing.Point(25, 53);
            this.radioButtongreen.Name = "radioButtongreen";
            this.radioButtongreen.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButtongreen.Size = new System.Drawing.Size(56, 17);
            this.radioButtongreen.TabIndex = 9;
            this.radioButtongreen.TabStop = true;
            this.radioButtongreen.Text = "الاخضر";
            this.radioButtongreen.UseVisualStyleBackColor = true;
            // 
            // radioButtonred
            // 
            this.radioButtonred.AutoSize = true;
            this.radioButtonred.Location = new System.Drawing.Point(27, 76);
            this.radioButtonred.Name = "radioButtonred";
            this.radioButtonred.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButtonred.Size = new System.Drawing.Size(54, 17);
            this.radioButtonred.TabIndex = 7;
            this.radioButtonred.TabStop = true;
            this.radioButtonred.Text = "الاحمر";
            this.radioButtonred.UseVisualStyleBackColor = true;
            // 
            // radioButtonblack
            // 
            this.radioButtonblack.AutoSize = true;
            this.radioButtonblack.Location = new System.Drawing.Point(25, 99);
            this.radioButtonblack.Name = "radioButtonblack";
            this.radioButtonblack.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButtonblack.Size = new System.Drawing.Size(56, 17);
            this.radioButtonblack.TabIndex = 6;
            this.radioButtonblack.TabStop = true;
            this.radioButtonblack.Text = "الاسود";
            this.radioButtonblack.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "HUSSAM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "لون النص";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(56, 69);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox3.Size = new System.Drawing.Size(44, 17);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "400";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(56, 86);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox4.Size = new System.Drawing.Size(44, 17);
            this.checkBox4.TabIndex = 9;
            this.checkBox4.Text = "500";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(56, 102);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox5.Size = new System.Drawing.Size(44, 17);
            this.checkBox5.TabIndex = 10;
            this.checkBox5.Text = "600";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // btnenabled
            // 
            this.btnenabled.Location = new System.Drawing.Point(146, 211);
            this.btnenabled.Name = "btnenabled";
            this.btnenabled.Size = new System.Drawing.Size(75, 23);
            this.btnenabled.TabIndex = 7;
            this.btnenabled.Text = "enabled";
            this.btnenabled.UseVisualStyleBackColor = true;
            this.btnenabled.Click += new System.EventHandler(this.btnenabled_Click);
            // 
            // btnunabled
            // 
            this.btnunabled.Location = new System.Drawing.Point(258, 211);
            this.btnunabled.Name = "btnunabled";
            this.btnunabled.Size = new System.Drawing.Size(75, 23);
            this.btnunabled.TabIndex = 8;
            this.btnunabled.Text = "unabled";
            this.btnunabled.UseVisualStyleBackColor = true;
            this.btnunabled.Click += new System.EventHandler(this.btnunabled_Click);
            // 
            // btnvisible
            // 
            this.btnvisible.Location = new System.Drawing.Point(146, 240);
            this.btnvisible.Name = "btnvisible";
            this.btnvisible.Size = new System.Drawing.Size(75, 23);
            this.btnvisible.TabIndex = 9;
            this.btnvisible.Text = "visible";
            this.btnvisible.UseVisualStyleBackColor = true;
            this.btnvisible.Click += new System.EventHandler(this.btnvisible_Click);
            // 
            // btnunvisible
            // 
            this.btnunvisible.Location = new System.Drawing.Point(258, 240);
            this.btnunvisible.Name = "btnunvisible";
            this.btnunvisible.Size = new System.Drawing.Size(75, 23);
            this.btnunvisible.TabIndex = 10;
            this.btnunvisible.Text = "unvisible";
            this.btnunvisible.UseVisualStyleBackColor = true;
            this.btnunvisible.Click += new System.EventHandler(this.btnunvisible_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 302);
            this.Controls.Add(this.btnunvisible);
            this.Controls.Add(this.btnvisible);
            this.Controls.Add(this.btnunabled);
            this.Controls.Add(this.btnenabled);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panelbackcolor);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelbackcolor.ResumeLayout(false);
            this.panelbackcolor.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelbackcolor;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButtonyellow;
        private System.Windows.Forms.RadioButton radioButtongreen;
        private System.Windows.Forms.RadioButton radioButtonred;
        private System.Windows.Forms.RadioButton radioButtonblack;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button btnenabled;
        private System.Windows.Forms.Button btnunabled;
        private System.Windows.Forms.Button btnvisible;
        private System.Windows.Forms.Button btnunvisible;
    }
}

