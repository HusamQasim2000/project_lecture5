﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lecture_5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

       

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            this.Left = 0;
            this.Width = this.Width + 100;
            this.Height = this.Height + 100;
            //btnplayer.Location = new Point(this.Width / 2, this.Height + 100);
            //btnplayer.Top = btnplayer.Top - 5;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //btnplayer.Top -= 5;
            btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top - 5);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //txtplayer.Height += 5;
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height + 5);
        }
        private void button4_Click(object sender, EventArgs e)
        {
            //txtplayer.Height -= 5;
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height - 5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //txtplayer.Top += 5;
            btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top + 5);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //txtplayer.Left += 5;
            btnplayer.Location = new Point(btnplayer.Left+5, btnplayer.Top);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnplayer.Width += 5;
            //txtplayer.Size = new Size(txtplayer.Width + 5, txtplayer.Height);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            btnplayer.Width -= 5;
            //txtplayer.Size = new Size(txtplayer.Width - 5, txtplayer.Height);
        }

        private void button7_Click(object sender, EventArgs e)
        {
           // txtplayer.Left -= 5;
            btnplayer.Location = new Point(btnplayer.Left - 5, btnplayer.Top);
        }
    }
}
